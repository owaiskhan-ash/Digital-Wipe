CUTE DINO — 3D MODEL PACK
=========================

Files
-----
cute-dino.glb   Binary glTF. Materials and colours included. Use this one for
                web (three.js / Babylon), Unity, Unreal, Blender, AR/Quick Look,
                or any online GLB viewer. ~2.1 MB.
cute-dino.obj   Wavefront OBJ, single mesh with material groups. Best for
                Blender / Maya / MeshLab when you want to sculpt or retopo.
                ~12 MB.
cute-dino.stl   Binary STL, geometry only (no colour). Slicer-ready for 3D
                printing. ~4.2 MB.

preview-side.png / preview-front.png   Orthographic renders of the model.
dino-reference.webp                    The original photo this was modelled from.

Model specs
-----------
Parts (meshes) : 73
Triangles      : ~86,000
Vertices       : ~49,000
Bounds         : 5.09 x 4.11 x 1.98 units (X x Y x Z)
Orientation    : faces +X, stands on Y = 0, symmetric about Z = 0.
Colourway      : Original green (body #aedc2a, plates #5f83c4, spots #4f6428)

Notes
-----
There are no textures — every surface is a solid PBR material, so the colours
survive export and the files stay small.

The model is an interpretation built from the one reference photo, so the far
side is a reasonable reconstruction rather than measured geometry.

To regenerate these files after editing lib/dino/buildDino.ts:
    npx tsx scripts/generate-dino-model.ts
